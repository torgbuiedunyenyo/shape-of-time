# The Shape of Time

## A Worldbuilding Document

---

## Part One: The Nature of Time

### Core Points: Time and Its Navigation

**Time's True Shape**
Time isn't a one-dimensional arrow pointing from past to future—it has at least three dimensions, just like space. Time and space are inseparable properties of a single thing called "spacetime." These three temporal axes are named: Primas (the familiar past/future axis), Phantas, and Mystas—each with "Major" and "Minor" directions. The common conception of time as a vector with only one existing moment (the present) is fundamentally wrong. There may be additional dimensions beyond these three, but understanding just these requires substantial effort.

**We're Not the Center**
Just as humanity once wrongly believed Earth was the center of the universe, we wrongly believe the "present" is the center of time. Defining all time relative to our current moment is as absurd as measuring all spatial distances from wherever we happen to stand—imagine saying "Sacramento is 345 miles from me" instead of "Sacramento is 100 miles from San Francisco." This self-centered framework makes time travel seem impossibly complicated, just as believing Earth was flat once made ocean travel seem impossible.

**Other Times Exist Independently**
The past doesn't freeze when we leave it, and the future already exists before we arrive. Times continue evolving whether we occupy them or not. If you leave Sacramento for San Francisco, you wouldn't assume Sacramento freezes in place or that San Francisco doesn't exist until you arrive—yet we make exactly these assumptions about time. This insight resolves classic paradoxes: there's no "two selves" problem because once you leave a moment, you're simply no longer there. If you return, you'll find that time changed in your absence, just as a city would.

**Mutual Causation**
All moments in time influence each other bidirectionally, like molecules of water affecting neighboring molecules in a lake. The future causes the present just as the past does, and effects travel along all temporal axes. Crucially, influence diminishes with distance—time is "self-healing." The dramatic "butterfly effect" of fiction is adolescent fantasy; a stone dropped in a lake creates ripples that fade, not amplify. Times closest to us are most affected by our movements.

**Why It Seems Linear**
Clocks run forward because they're programmed to—writing "12:00" on a wall doesn't determine when the wall actually is. We age not because time flows in one direction, but because movement through time in *any* direction wears down the body, like wagon wheels wearing regardless of direction.

**Practical Navigation**
Effective time travel requires establishing stable reference points outside ourselves and mapping temporal "currents" like ocean flows—a three-dimensional vector field, not static points. Understanding causation must expand to include all temporal directions. Technology for rapid time travel remains primitive; we haven't "invented the wheel" because we didn't believe movement was possible. Early experimentation suggests unusual spatial movements (circular motion, moving backward) and potentially light or heat may accelerate temporal navigation.

---

## Part Two: Time Travel Technology

### The Invention of PRMTTs

Prostheses for Rapid Movement Through Time (PRMTTs) were developed over centuries following the initial understanding of time's true nature. The first breakthroughs involved:

- Continuous circular movements in multiple directions (moving around a circle while spinning)
- Movement while facing unusual directions (backward, sideways)
- Vertical or diagonal elevation via mechanical means
- Manipulation of light and heat (mirrors, focused thermal energy)

These crude methods evolved over generations into sophisticated technology. In the future era where Tan lives, PRMTTs are manufactured devices—compact, reliable, and ubiquitous among those who can afford them.

### How PRMTTs Work

PRMTTs do not teleport users through time. They accelerate movement along temporal axes in the same way vehicles accelerate movement through space. Travel still takes time (in the experiential sense) and still requires navigation.

The devices work by generating specific patterns of spatial movement, light, and thermal energy that human bodies cannot produce unassisted. The user experiences a sensation of motion, though their spatial position may not change significantly. Journeys of significant temporal distance can take hours or days of subjective experience.

PRMTTs require calibration to the user's destination. This is where temporal mapping becomes essential. Without accurate maps of temporal flows, a PRMTT user can become lost, arrive at an unintended time, or worse—drift toward the unmapped edges from which return becomes increasingly difficult.

### Temporal Mapping

Time flows like currents in water. Mapping these flows is laborious work, more akin to charting ocean currents than surveying land. Maps must be three-dimensional, constantly updated, and cross-referenced with other mappers' observations.

In the future, temporal cartography is a sophisticated profession supported by advanced instruments. Temporal maps are proprietary corporate assets. Major PRMTT companies maintain the most comprehensive maps, which gives them enormous power over who can travel where and when.

In the past, temporal mapping is primitive or nonexistent. Most people don't know it's possible. Underground cartographers exist—self-taught individuals who've figured out more than most—but their maps are localized and incomplete.

### The Leading PRMTT Company

Tan's father is a powerful executive at the leading PRMTT manufacturer. This company (unnamed as yet) controls:

- The most comprehensive temporal maps in existence
- The most advanced PRMTT devices
- Significant influence over temporal immigration policy
- Extensive infrastructure at key temporal transit points

The company's official business is facilitating tourism and commerce across eras. Its unofficial business includes resource extraction from the past, influence over past governments, and—at the edges of its operations—exploration of the unmapped regions that border known time.

---

## Part Three: The Political Economy of Time

### The Extraction Economy

The relationship between eras mirrors relationships between wealthy and poor nations, between metropole and periphery. The future is wealthy; the past is exploited. This manifests in several ways:

**Resource Extraction:** The future sends operations into the past to extract natural resources, raw materials, and other commodities that have been depleted or are expensive in their own time. These operations are conducted with the cooperation of past governments, whose leaders personally profit while their populations bear the costs.

**Tourism:** Wealthy future citizens travel to the past for entertainment, novelty, and aesthetic experience. Entire eras have been transformed by this tourism. The past becomes a performance of itself.

**Labor Arbitrage:** Services and goods are cheaper in the past due to lower living standards. Future companies outsource various operations to past eras.

**Cultural Extraction:** Art, music, cuisine, and other cultural products are taken from the past and sold in the future, often without compensation or attribution.

### The Transformation of the Past

Future influence has reshaped past eras in profound ways. In 2025 Oakland, for example:

- Liquor stores sell clef, a substance popular among future tourists, despite clef not existing in "original" 2025
- Businesses cater to future customers, accepting future payment methods and stocking future preferences
- Real estate in desirable temporal tourism zones has been bought up by future investors
- Local economies depend on future spending
- Medical services, transportation options, and other infrastructure have been upgraded in tourist areas, creating stark inequalities between zones that attract future visitors and those that don't

The past is not "ruined" by this influence in the sense of being damaged—it has simply evolved in response to forces from all temporal directions, as all times do. But the specific direction of that evolution has been shaped by future wealth and power.

### The Blitz Example

The Nazi Blitz in England is a popular temporal tourism destination. So many future tourists have visited, and so much future money has flowed into the era, that the experience has transformed completely. The bombings still occur, but they are now performative—managed spectacles that tourists observe from safe vantage points. When the sirens sound, locals play their roles, heading to shelters with practiced calm. The danger is real enough to be thrilling, controlled enough to be safe.

Locals in Blitz-era England make their living from this tourism. Some resent it; others are grateful for the economic opportunity; most simply accept it as how things are. The "authentic" wartime experience future tourists seek was always a construction—the Blitz was never pristine, was always being shaped by its own future.

### Immigration Controls

Travel from the past to the future is tightly restricted. Temporal immigration policy is set by future governments under heavy corporate influence. The official justifications are:

- Resource scarcity (the future's resources are already strained)
- Cultural preservation (too many immigrants would change future society)
- Security concerns (past people might bring diseases, criminal tendencies, or destabilizing ideas)

The real reasons include:

- Labor market protection (cheap past labor would undercut future workers if allowed to immigrate freely)
- Maintaining the wealth differential that makes extraction profitable
- Keeping past populations available as a tourism product

Visas for past-to-future travel are rare and conditional. Most require sponsorship by a future citizen or corporation. Visitors must return by specified dates. Overstaying is a serious crime. Enforcement is aggressive.

A black market exists for forged temporal documentation, illegal transit routes, and fixers who help past people disappear into the future. Jay does not use these services—he enters legally through Tan's father's influence—but he becomes aware of them during his flight from authorities.

### Class and Temporal Origin

In the future, temporal origin functions like national origin, race, or class in other contexts. People from the past are viewed with suspicion and condescension. Common assumptions include:

- They're economically motivated (trying to access future wealth)
- They're culturally backward (don't understand future norms)
- They're potentially criminal (past eras are seen as more violent and lawless)
- They're romantically suspect (relationships with future people are assumed to be transactional)

Slurs and derogatory terms exist for past people, though the specific words are not detailed here. Future people who associate too closely with past people face social stigma.

Past people in the future often cluster in specific neighborhoods, work specific jobs, and exist in a legal gray zone even when their documentation is legitimate. Jay experiences this immediately upon arrival.

---

## Part Four: The Unmapped Edges

### What the Edges Are

"The edges of known time" refers to the boundaries of mapped temporal space. Beyond these boundaries, temporal flows are uncharted, PRMTT navigation becomes unreliable, and travelers risk becoming permanently lost.

The edges exist in all three temporal dimensions, but the most distant and least explored edges lie along the Mystas axis. Few people travel far along Mystas; fewer return from its extremes.

### What Lies There

The Mystas edges are not inherently more dangerous than mapped regions—time's fundamental properties remain consistent everywhere. The danger is practical: without reliable maps, travelers cannot predict where currents will carry them.

The currents at the edges are fast, turbulent, and constantly shifting. Mapping efforts fail because the territory changes faster than cartographers can chart it. Travelers who venture too far find themselves carried by flows they cannot anticipate toward regions no one has documented. Without landmarks or reference points, they cannot find their way back.

The PRMTT companies have lost expeditions to the edges. They maintain research stations at the boundaries of mapped space, slowly extending their charts, but progress is difficult. Some regions have been mapped and then "lost" when currents shifted and the maps became obsolete.

Rumors circulate about what lies in the deep unmapped regions—travelers' tales of strange times, impossible places, zones where familiar rules seem not to apply. Most of these stories are exaggerations or fabrications. The truth is simpler and more frightening: no one knows what's out there, because no one who's gone far enough has returned to tell.

### The Company's Involvement

Tan's father's company is deeply involved in edge exploration. The company maintains research stations near the Mystas boundaries. It has developed instruments to track current patterns. It has mapped further than any competitor.

The company's interest is partly scientific, partly commercial. If the edges can be mapped, they can be traveled. New temporal territories mean new resources, new tourism destinations, new markets. The company that charts the edges first will control access to whatever lies beyond.

Tan, through her father's position, had access to information about the company's edge operations. She learned about the expeditions, the losses, the slow progress. This knowledge sparked her curiosity about seeing the edges for herself.

---

## Part Five: The Characters

### Jay

Jay is a young man living in Oakland in 2025. He works at a shop (a liquor store or convenience store) that serves both local customers and future tourists. He sells clef, among other things. His economic existence depends on future money.

Jay is not formally educated in temporal mechanics, but he has the practical knowledge of someone who's grown up in an era saturated with future influence. He's used to wealthy strangers appearing and disappearing, used to products and trends that don't quite make sense, used to navigating a world that doesn't fully belong to his own time.

He is temporally illiterate in the formal sense—he can't read temporal maps, doesn't know how to calibrate a PRMTT. But he's observant. He notices things. He's survived by paying attention to what doesn't add up.

When Tan enters his shop and struggles with payment, he recognizes her as a future person immediately—not from any single detail, but from the aggregate of small wrong notes. Her confusion with the phone. Her clothes that are slightly off. Her assumption that things should work differently. He gives her the clef for free partly out of kindness, partly out of curiosity, partly because he's drawn to her in a way he doesn't fully understand.

Jay is not naive about the power imbalance between them. He knows how relationships like theirs are perceived. He falls in love with Tan anyway, or perhaps because of this knowledge—because she seems to see him as a person rather than a curiosity or a transaction.

### Tan

Tan is a young woman from the future. Her father is a powerful executive at the leading PRMTT company. She has grown up wealthy, privileged, and educated in temporal mechanics. She can operate PRMTTs fluently and read temporal maps with ease.

She comes to 2025 Oakland as a tourist, initially. It's a popular destination—gritty, authentic, a taste of the "real" past before it became too transformed. She's been to other eras, other places. She's comfortable traveling through time in a way Jay will never be.

When she enters Jay's shop, her confusion with the phone is genuine. Payment technology in her era involves neural interfaces; she's never had to use a physical device for transactions. Her embarrassment at appearing incompetent in front of a past person—someone she's been raised to see as less sophisticated—makes her defensive and suspicious. When Jay simply gives her the clef, she's disarmed. It's not a transaction she knows how to process.

Their friendship develops over subsequent visits. She keeps returning to his shop, then to other places with him, then to his life. She tells herself she's interested in authentic past culture. She doesn't admit, at first, that she's interested in him.

Tan has complicated feelings about her father's company and the temporal economy she benefits from. She's not an activist or a revolutionary—she's grown up inside the system and has the blind spots that come with privilege—but she's not comfortable either. She asks questions. She notices contradictions. This quality is what eventually leads her to become curious about the edges.

Her relationship with Jay is genuine in its way. She does care about him. But she has never had to consider him as fully as she considers herself. The gap between them is not something she's ever been forced to reckon with—she can always leave.

### Tan's Father

Tan's father is an executive at the leading PRMTT company—high enough to have real power, not high enough to control the company's overall direction. He loves his daughter. He has justified his participation in various corporate activities over the years.

When Tan brings Jay to the future, her father facilitates it. He's not enthusiastic about the relationship, but he's not willing to break with his daughter over it. He pulls strings to get Jay a visa, housing, a path toward legitimacy. He tells himself he's being supportive. He's also keeping them close, where he can monitor the situation.

Her father knows more about the edge expeditions than almost anyone outside the company's inner circle. He knows how many have been lost. He's been trying to protect Tan from developing too much interest in the unmapped regions.

When Tan disappears, her father's reaction is complicated. He may genuinely not know where she is. His cooperation with authorities in blaming Jay may be genuine belief, or a convenient narrative, or simply the path of least resistance.

### The Authorities

Law enforcement in the future treats Jay as the obvious suspect. He's a past person. He was the last one seen with Tan. The relationship was already viewed as suspicious. The investigation is cursory; the conclusion is predetermined.

Beyond official law enforcement, Tan's father's company has its own security apparatus. These corporate agents have resources and reach that exceed government authorities. They can operate across eras, access temporal maps and transit infrastructure, and pursue targets with a persistence that public police cannot match.

Jay is running from both. The police want to arrest him. The company wants something else—possibly to silence him, possibly to recover something Tan had, possibly to prevent him from reaching the edges where their operations are conducted.

---

## Part Six: The Plot

### Part One: Meeting and Courtship (2025)

Jay and Tan meet in his shop. She's confused by the phone; he gives her the clef for free. She keeps coming back. They become friends, then more. The relationship develops against the backdrop of Oakland's future-saturated economy—the tourists, the clef sales, the constant awareness of the wealth gap between eras.

Jay falls in love with Tan. Tan falls in love with Jay, or something like it. Both are aware of how their relationship looks from the outside. Both proceed anyway.

### Part Two: Arrival in the Future

Tan wants Jay to see her world. Her father arranges documentation. They travel to the future together.

Jay's experience of the future is disorienting. The technology is unfamiliar, the social cues are different, the layout of cities follows patterns he doesn't understand. He depends on Tan to navigate.

The social dynamics are worse. Everyone assumes he's with Tan for citizenship, money, status. He's treated as a curiosity at best, a predator at worst. Tan's friends are polite but condescending. Her family is cold.

Jay tries to adapt. He studies temporal mechanics, looks for work that doesn't require skills he doesn't have. Progress is slow and humiliating.

### Part Three: The Disappearance

A few days after their arrival, Tan disappears.

She had been acting strangely in the days before—distracted, excited, secretive. She'd mentioned something about the edges, about wanting to see for herself what was out there. Jay didn't fully understand what she meant.

The night she disappears, she tells Jay she needs to check on something. She'll be back soon. She doesn't say where she's going. She doesn't come back.

Jay reports her missing. Within hours, he's the primary suspect. The investigation focuses entirely on him. His past-person status, his economic motive, his lack of alibi—everything points to him. He's detained, questioned, released under surveillance, then learns that charges are imminent.

He runs.

### Part Four: The Flight and Investigation

Jay flees into the temporal margins—times and routes that aren't heavily monitored, places where past people disappear into the cracks of the system. He makes contact with the underground networks that help temporal immigrants: forgers, fixers, people who know hidden paths through time.

He's not just running; he's investigating. He retraces Tan's final days. He learns about her father's company, about the research stations at the edges, about the expeditions that never returned. He discovers that Tan had been curious about the same things—not out of moral outrage, but out of adventurous interest.

His investigation takes him through multiple eras:

- Back to 2025 Oakland, which has changed in his absence—his shop is different, people don't quite remember him right, the time has continued evolving without him
- To other past eras where the company has operations
- To future times he can access through underground channels
- Eventually, toward the Mystas edges where rumors suggest Tan may have gone

Along the way, he learns to navigate through study and practice. He becomes something he never expected: a competent time traveler, self-taught under pressure.

### Part Five: The Truth

Jay eventually discovers what happened to Tan.

She went to the Mystas edges. Not because she was silenced or kidnapped or caught up in conspiracy—but because she wanted to. She'd learned about the unmapped regions, found them fascinating, and decided to go see for herself. It was an adventure. She had the resources, the training, the equipment. She didn't think to tell anyone because she planned to explain it all when she got back, "in her own time."

She didn't consider what her disappearance would mean for Jay. It didn't occur to her that he would be blamed, hunted, forced to flee through time to clear his name. She wasn't being cruel—she simply didn't think about it. He wasn't real to her in the way she was real to herself.

Jay finds her returning from the edges, or at a station near them. She's fine. She's had an incredible experience. She's excited to tell him about it.

### Part Six: Resolution

Jay has to decide what to do with this.

He's spent weeks or months running, hiding, learning to survive across times. He's been terrified, exhausted, transformed. He's developed skills he never knew he could have. He's seen things about how the world works—about the company's operations, about the future's exploitation of the past—that he can never unsee.

And Tan didn't think about him at all.

He decides to forgive her. Not because what she did was acceptable, but because holding onto anger would cost him more than letting it go. He understands, now, that the gap between them was always larger than he wanted to believe. She cared about him, in her way. But he was never as real to her as she was to him.

They try, briefly, to continue. But Tan doesn't want to do the work. The relationship requires her to see Jay fully, to account for the power between them, to change how she moves through the world. She's not willing. It's easier to let him go.

Jay returns to Oakland, to 2025, to his shop. The time has changed in his absence—it's not quite the place he left—but it's still recognizable. He's different now. He understands things about the structure of the world that most people in his era don't know.

He goes back to work. He sells clef to future tourists. He watches them come and go, knowing what he knows, carrying what he's learned. The edges remain unmapped. The exploitation continues. Nothing has been fixed.

But Jay is still here. He's survived. And he knows, now, that there's more to time than the single direction he was taught to see.

---

## Part Seven: Additional Worldbuilding Details

### Clef

Clef is a substance popular among future tourists visiting past eras. Its exact nature is not specified, but it functions socially like a regional delicacy or a local drug—something you consume "when in 2025 Oakland" as part of the authentic experience.

Clef exists in 2025 Oakland because of omnidirectional causation. Future demand for clef in 2025 caused it to exist there. This is not a paradox; it's simply how time works. The future shaped the past, as all times shape all other times.

Clef is legal in 2025 (it's sold in liquor stores) but may have a different legal status in the future, making past eras an attractive place to consume it without consequences.

### Temporal Tourism Destinations

Popular destinations for future tourists include:

- The Blitz (London, 1940-1941): Now a managed spectacle, the bombings are performative, the danger controlled, the locals playing their roles for tourist money.
- Pre-contact indigenous eras: Controversial "cultural experiences" that indigenous communities of the future have largely succeeded in restricting.
- Various "gritty" urban environments: 2025 Oakland, 1970s New York, other eras seen as authentically rough.
- Historical events: Battles, speeches, coronations—all transformed by the presence of tourist observers.

The most popular destinations have been the most transformed. Purist tourists complain endlessly about this while continuing to visit.

### Preservation Zones

In response to complaints about authenticity, some temporal zones have been designated as preservation areas where future influence is restricted. These are essentially human zoos—eras kept artificially "pristine" by limiting the economic development that would naturally occur from temporal contact.

Preservation zones are controversial. Residents are kept in relative poverty to maintain the aesthetic that tourists want. The ethics of this are debated in the future, but the zones persist because they're popular.

### Language and Communication

Language drift over time creates communication barriers between eras. Future people and past people speak recognizably the same language, but idioms, references, slang, and even some basic vocabulary have shifted. Tan and Jay can understand each other, but there are constant small moments of confusion or mistranslation.

Translation technology exists in the future but is imperfect. Jay often misses nuances in future conversation.

### Technology Gaps

Beyond PRMTTs, future technology is substantially advanced:

- Neural interfaces have replaced most physical devices (hence Tan's confusion with Jay's phone)
- Medical technology has extended lifespans and cured most diseases
- Communication is largely neural rather than verbal or textual
- Transportation within an era uses methods Jay doesn't understand

When Jay is in the future, he struggles with basic daily activities that require technological fluency he doesn't have.

### The Underground Networks

A substantial underground exists to help past people navigate the future illegally. This includes:

- Document forgers who create convincing temporal visas
- Guides who know routes through time that avoid monitored transit points
- Safe houses in various eras where people can hide from authorities
- Fixers who can arrange employment, housing, and identity in the future for those who want to disappear

Jay makes contact with these networks during his flight. They're initially suspicious of him—he entered the future legally, through corporate sponsorship—but come to trust him as his situation becomes clear.

### Temporal Slang and Prejudice

Future people use various terms for past people, mostly derogatory. Past people have their own terms for future people, though these carry less social weight given the power differential.

Common prejudices about past people:

- They're violent (past eras are seen as barbaric)
- They're disease carriers (past medical standards were lower)
- They're sexually aggressive (past gender relations were more unequal)
- They're economically desperate (true, given the wealth gap)
- They smell wrong (different diets, different hygiene products)

Past people who successfully assimilate into the future often try to hide their temporal origin, though this becomes difficult under scrutiny.